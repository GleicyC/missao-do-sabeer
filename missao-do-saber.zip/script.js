function falar(texto) {
  const narrador = window.speechSynthesis;
  const fala = new SpeechSynthesisUtterance(texto);
  fala.lang = 'pt-BR';
  narrador.cancel(); // Evita sobreposição de falas
  narrador.speak(fala);
  document.getElementById("narrador").innerText = texto;
}

function escolherPersonagem(nome) {
  falar(`Você escolheu ${nome}. Vamos começar a aventura!`);
  setTimeout(faseMatematica, 3000);
}

function faseMatematica() {
  const container = document.getElementById("fase");
  container.innerHTML = `
    <p>Missão 1: Tenho quatro patas, mas não corro. O que sou?</p>
    <button onclick="responder1('A')">A - Um cachorro</button>
    <button onclick="responder1('B')">B - Uma cadeira</button>
    <button onclick="responder1('C')">C - Um carro</button>
  `;
  falar("Missão 1. Tenho quatro patas, mas não corro. O que sou? Alternativa A: Um cachorro. B: Uma cadeira. C: Um carro.");
}

function responder1(resp) {
  if (resp === 'B') {
    falar("Parabéns! Você acertou! Vamos para a próxima missão.");
    setTimeout(fasePortugues, 3000);
  } else {
    falar("Resposta incorreta. A resposta certa era B - Uma cadeira.");
  }
}

function fasePortugues() {
  const container = document.getElementById("fase");
  container.innerHTML = `
    <p>Missão 2: Complete a palavra C A V A L _</p>
    <button onclick="responder2('A')">A - E</button>
    <button onclick="responder2('B')">B - O</button>
    <button onclick="responder2('C')">C - U</button>
  `;
  falar("Missão 2. Complete a palavra. C A V A L. Alternativa A: E. B: O. C: U.");
}

function responder2(resp) {
  if (resp === 'B') {
    falar("Muito bem! A palavra é cavalo. Você concluiu a missão!");
  } else {
    falar("Resposta incorreta. A letra correta era O.");
  }
}